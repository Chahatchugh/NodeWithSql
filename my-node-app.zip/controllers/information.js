const Information = require('../models/information');
const Movies = require('../models/movies');
const WatchedList = require('../models/watchedList')
exports.getInformation = (req, res, next) => {
    Information.findAll()
    .then((info) => {
      res.render('information/index', { prods: info, pageTitle: 'Information', path:'/' });
    })
  .catch(err => console.log(err));
    // (info => {
    //   res.json(info);
    // });
  };

exports.postInformation =(req, res, next) => {
    var userName = req.body.userName;
    if (userName) {
        res.render('information/netflix', { pageTitle: 'Information', path:'/' , userName: userName});
    } else { 
      res.redirect('/');
    }
}

exports.getMovies = (req, res, next) => {
  // req.user.getWatchedList()
  // .then((list)=>{
  //   return list.getMovies()
  // })
  // .then(res => {
  //   console.log(res)
  // })
  Movies.findAll()
  .then((info) => {
    const watch =req.user
    console.log(watch)
    res.render('information/movies', { movies: info, pageTitle: 'Information', path:'/' ,  hasInfo: info.length > 0 ,  });
  })
.catch(err => console.log(err));
  // (info => {
  //   res.json(info);
  // });
};

exports.postWatchedList =(req, res, next) => {
  var movieId = req.body.id;
  if (movieId) {
    req.user.getWatchedList()
    .then(watchList => {
      Movies.findByPk(movieId)
      .then(result=>{
         return watchList.addMovie(result)
        .then(() => {
          res.redirect('/watchedList');
      })
        .catch(err => console.log(err,'err'))
      }) 
    })
  } else { 
    res.redirect('/');
  }
}

exports.getWatchedList = (req, res, next) => {
  req.user.getWatchedList()
  .then((list)=>{
  return list.getMovies()
  .then((info) => {
    res.render('information/watchedList', { movies: info, pageTitle: 'Information', path:'/' ,  hasInfo: info.length > 0 });
  })
.catch(err => console.log(err));
  // (info => {
  //   res.json(info);
  // });
})
};

exports.getDetail = (req , res , next) =>{
  const movieId = req.params.movieId;
  Movies.findByPk(movieId).then(movie => {
      res.render('information/detail', { movies: movie, pageTitle: movie.title, path: '/movies' });
  })
  .catch(err => console.log(err));
}

exports.postWatchedDeleteItem = (req , res , next) =>{
  const movieId = req.body.id;
  req.user.getWatchedList()
  .then(movie => {
      return movie.getMovies({where: { id: movieId }})
  })
  .then(movies => {
      const movie = movies[0];
      return movie.watchedItem.destroy();
  })
  .then(result => {
      res.redirect('/watchedList')
  })
  .catch(err => console.log(err))
}

exports.getAddMovie = (req , res , next) =>{
  res.render('information/addMovie', { pageTitle: 'Add Movie', path: '/', editing: false });
}

exports.postAddMovie = (req, res , next) =>{
  const movieName = req.body.movieName;
  const url = req.body.url;
  // added by sequelize - create{{MODAL_NAME}}
  Movies.create({
    movieName: movieName,
    url: url,
  }).then(result => {
      res.redirect('/movies');        
  }).catch(err => {
      console.log(err)
  });
}

exports.getEditMovie = (req , res , next) =>{
  const editMode = req.query.edit;
  if(!editMode) {
      res.redirect('/');
  }
  const movieId= req.params.movieId;
  Movies.findByPk(movieId)
  .then(movie => {
    // console.log('movie' , movie)
      // const movies = movie[0];
      // console.log(movies , 'dghghhgdgdgddg')
      if(!movie) return res.redirect('/')
      res.render('information/addMovie', { pageTitle: 'Edit Movie', path: '/', editing: editMode, movies: movie });
  })
  .catch(err => console.log(err));
}

exports.postEditMovie = (req , res , next)=>{
  const movieId = req.body.id;
  const movieNameUpdated = req.body.movieName;
  const urlUpdated = req.body.url;
  Movies.findByPk(movieId)
  .then(movie => {
    movie.movieName = movieNameUpdated;
    movie.url = urlUpdated;
      return movie.save();
  })
  .then(result => {
      res.redirect('/movies');
  })
  .catch(err => console.log(err));
}

exports.postDeleteMovie = (req , res , next) =>{
  const movieId = req.body.id;
  Movies.destroy({where: {id: movieId}})
  .then(result => {
      res.redirect('/movies');    

  })
  .catch(err => console.log(err));
}