const express = require('express');
const informationController = require('../controllers/information');

const router = express.Router();
router.get('/', informationController.getInformation);
router.post('/netflix', informationController.postInformation);
router.get('/movies' , informationController.getMovies);
router.post('/watchedList' , informationController.postWatchedList)
router.get('/watchedList' , informationController.getWatchedList)
router.get('/movies/:movieId', informationController.getDetail);
router.post('/watched-delete-item', informationController.postWatchedDeleteItem)
router.get('/addMovie', informationController.getAddMovie);
router.post('/addMovie', informationController.postAddMovie);
router.get('/addMovie/:movieId', informationController.getEditMovie);
router.post('/editMovie', informationController.postEditMovie);
router.post('/deleteMovie' , informationController.postDeleteMovie)

module.exports = router;