const Sequelize = require('sequelize');
const sequelize = require('../util/database');


var Movies = sequelize.define('movies', {
  id: {
    type: Sequelize.INTEGER, 
    autoIncrement: true,
    allowNull: false,
    primaryKey: true
  },
    movieName: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: 'compositeIndex'
    },
    url: {
      type: Sequelize.STRING,
      unique: 'compositeIndex'
    }
}
)

module.exports = Movies;