const Sequelize = require('sequelize');
const sequelize = require('../util/database');


var watchedList = sequelize.define('watchedList', {
  id: {
    type: Sequelize.INTEGER, 
    autoIncrement: true,
    allowNull: false,
    primaryKey: true
  },
}
)

module.exports = watchedList;