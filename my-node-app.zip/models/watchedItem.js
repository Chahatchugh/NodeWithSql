const Sequelize = require('sequelize');
const sequelize = require('../util/database');


var WatchedItem = sequelize.define('watchedItem', {
    id: {
        type: Sequelize.INTEGER, 
        unique: true,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    }
}
)

module.exports = WatchedItem;