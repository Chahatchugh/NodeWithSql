const Sequelize = require('sequelize');
const sequelize = require('../util/database');


var Information = sequelize.define('user', {
    userId: {
        type: Sequelize.INTEGER, 
        unique: true,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    firstName: {
      type: Sequelize.STRING,
      allowNull: false,
      unique: 'compositeIndex'
    },
    lastName: {
      type: Sequelize.STRING,
      unique: 'compositeIndex'
    },
    dob: { 
        type: Sequelize.DATE, 
        unique: 'compositeIndex'
    }
}
)

module.exports = Information;