
const bodyParser = require('body-parser');
const express = require('express');
const sequelize = require('./util/database');
const Information = require('./models/information');
const informationRoute = require('./routes/information');
const expressHbs = require('express-handlebars');
const User = require('./models/information');
const WatchedList = require('./models/watchedList');
const WatchedItem = require('./models/watchedItem')
const Movies =  require('./models/movies');
const app = express();
app.engine('hbs', expressHbs({ layoutsDir: 'views/layouts/', defaultLayout: 'main-layout', extname: 'hbs' }));
app.set('view engine', 'hbs');
app.set('views', 'views'); 
app.use(bodyParser.urlencoded({ extended: false }));


// Particular User

app.use((req, res, next) => {
    Information.findByPk(1)
    //Information.findByPk(2)
    .then(user => {
        req.user = user;
        next();
    })
    .catch(err => console.log(err));
});


User.hasOne(WatchedList);
WatchedList.belongsTo(User , {constraints: true, onDelete: 'CASCADE'});    //when a product is deleted from entire app 

WatchedList.belongsToMany(Movies , {through : WatchedItem});
Movies.belongsToMany(WatchedList , {through : WatchedItem});

app.use(informationRoute);
app.use((req, res, next) => {
    res.status(404).render('404', { pageTitle: 'Page Not Found', path: '' });
})
sequelize.sync()
.then(result => {
    return User.findByPk(1);
})
.then(user => {
    if(!user) {
        User.create({ firstName: 'mayank', lastName: 'yadav' , dob:'2019-12-12' })
    }
    return user;
})
.then(info => {
    app.listen(3000);
})
.catch(err => {
    console.log(err);
});

